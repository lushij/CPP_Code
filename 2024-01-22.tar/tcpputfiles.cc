#include"_public.h"
using namespace idc;
struct arg_t{
    int clientType;//客户端的类型，1-上传2-下载本程序固定1
    char ip[31];//服务端的ip
    int port;//服务端的端口号
    char cPath[256];//本地文件存放的根目录 
    int type;//文件上传后本地文件的处理方式1-删除2-移动备份目录
    char cBkPath[256];//2对应的备份目录
    bool andChild;
    char matcher[256];
    char sPath[256];//服务端文件存放的本地目录
    int time;
    int timeout;
    char pidName[256];//进程的名字
}ArgInfo;

clogfile logFile;//服务程序的运行日志
ctcpclient tcpClient;//创建tcp通讯客户端
cpactive pactive;//心跳对象
void useHelp();//帮助文档
bool Login(const char*str);//客户端连接函数
bool xmlToArg(const char*arg);//解析xml参数到结构体函数对象
void EXIT(int sig);
bool _tcpputfile(bool& fg);
bool acttest();
string strrecvbuffer;//处理接收到的报文
string strsendbuffer;//发送的报文


int main(int argc,char*argv[])
{
    if(argc!=3)
    {
        useHelp();
        return -1;
    }
    //设置关闭全部的io
    signal(2,EXIT);
    signal(15,EXIT);
    cout<<"打开日志..."<<endl;
    if(logFile.open(argv[1])==false)
    {
        //打开日志失败
        cout<<"打开日志"<<argv[2]<<"失败"<<endl;
        return -1;
    }
    //解析xml文件
    if(xmlToArg(argv[2])==false)
    {
        logFile.write("xmlToArg failed\n");
        return -1;
    }
    logFile.write("xmlToArg suc\n");
    pactive.addpinfo(ArgInfo.timeout,ArgInfo.pidName);

    if(tcpClient.connect(ArgInfo.ip,ArgInfo.port)==false)
    {
        logFile.write("connect is failed\n");
        return -1;
    }
    if(Login(argv[2])==false)
    {
        logFile.write("login failed\n");
        return -1;
    }
    bool flag=true;//如果调用_tcpputfiles()发送文件中，flag=true,反之为false
    while(1)
    {
        //调用_tcpputfiles(),执行上传文件的任务
        if(_tcpputfile(flag)==false)
        {
            logFile.write("上传失败\n");
            EXIT(-1);
        }
        //但是如果刚刚上传的文件过大，所需时间可能过长，新来的文件
        //为了保证文件被尽快上传，进程不休眠。（只有在刚才文件上传任务的时候没有上传文件的情况下才休眠)
        if(flag==false)
        {
            sleep(ArgInfo.time);
            if(acttest()==false)
            {
                break;
            }
        }
    }
    return 0;
}

void EXIT(int sig)
{
    printf("收到%d sig信号，程序退出\n",sig);
    exit(0);
}
void useHelp()
{
    printf("\n");
    printf("Using:~/project/tools/bin/tcpputfiles logfilename xmlbuffer\n\n");

    printf("Sample:~/project/tools/bin/procctl 20 ~/project/tools/bin/tcpputfiles ~/log/idc/tcpputfiles_surfdata.log "\
              "\"<ip>127.0.0.1</ip><port>5005</port>"\
              "<cPath>/tmp/client</cPath><type>1</type>"
              "<sPath>/tmp/server</sPath>"\
              "<andchild>true</andchild><matcher>*.xml,*.txt,*.csv</matcher><time>10</time>"\
              "<timeout>50</timeout><pidName>tcpputfiles_surfdata</pidName>\"\n\n");

    printf("本程序是数据中心的公共功能模块，采用tcp协议把文件上传给服务端。\n");
    printf("logfilename   本程序运行的日志文件。\n");
    printf("xmlbuffer     本程序运行的参数，如下：\n");
    printf("ip            服务端的IP地址。\n");
    printf("port          服务端的端口。\n");
    printf("type         文件上传成功后的处理方式：1-删除文件；2-移动到备份目录。\n");
    printf("cPath    本地文件存放的根目录。\n");
    printf("cBkPath 文件成功上传后，本地文件备份的根目录，当type==2时有效。\n");
    printf("andchild      是否上传cPath目录下各级子目录的文件，true-是；false-否，缺省为false。\n");
    printf("matcher     待上传文件名的匹配规则，如\"*.TXT,*.XML\"\n");
    printf("sPath       服务端文件存放的根目录。\n");
    printf("time      扫描本地目录文件的时间间隔，单位：秒，取值在1-30之间。\n");
    printf("timeout       本程序的超时时间，单位：秒，视文件大小和网络带宽而定，建议设置50以上。\n");
    printf("pidName         进程名，尽可能采用易懂的、与其它进程不同的名称，方便故障排查。\n\n");
}

bool xmlToArg(const char * str)
{
    bzero(&ArgInfo,sizeof(struct arg_t));
    getxmlbuffer(str,"ip",ArgInfo.ip,30);
    if(strlen(ArgInfo.ip)==0)
    {
        cout<<"failed"<<endl;
        return false;
    }
    getxmlbuffer(str,"port",ArgInfo.port);
    getxmlbuffer(str,"cPath",ArgInfo.cPath,250);
    string tmp="/home/";
    const char *sysUser=getlogin();//获取当前系统的用户名
    cout<<sysUser<<endl;
    tmp=tmp+sysUser+ArgInfo.cPath;
    bzero(&ArgInfo.cPath,sizeof(ArgInfo.cPath));
    strncpy(ArgInfo.cPath,tmp.c_str(),250);
    cout<<"cPath="<<ArgInfo.cPath<<endl;
    tmp.clear();
    getxmlbuffer(str,"cBkPath",ArgInfo.cBkPath,250);
    tmp=string("/home/")+sysUser+ArgInfo.cBkPath;
    bzero(&ArgInfo.cBkPath,sizeof(ArgInfo.cBkPath));
    strncpy(ArgInfo.cBkPath,tmp.c_str(),250);
    tmp.clear();
    cout<<"cBkPath="<<ArgInfo.cBkPath<<endl;
    getxmlbuffer(str,"type",ArgInfo.type);
    getxmlbuffer(str,"andChild",ArgInfo.andChild);
    getxmlbuffer(str,"matcher",ArgInfo.matcher,250);
    getxmlbuffer(str,"time",ArgInfo.time);
    getxmlbuffer(str,"sPath",ArgInfo.sPath,250);
    tmp=string("/home/")+sysUser+ArgInfo.sPath;
    bzero(&ArgInfo.sPath,sizeof(ArgInfo.sPath));
    strncpy(ArgInfo.sPath,tmp.c_str(),250);
    tmp.clear();
    cout<<"sPath="<<ArgInfo.sPath<<endl;
    getxmlbuffer(str,"timeout",ArgInfo.timeout);
    getxmlbuffer(str,"pidName",ArgInfo.pidName,250);
   if(ArgInfo.time>30)ArgInfo.time=30;//没必要超过30s
   if(ArgInfo.timeout<=ArgInfo.time)
   {
       logFile.write("starg.timeout(%d) <= starg.timetvl(%d).\n",ArgInfo.timeout,ArgInfo.time); return false;
   }
   return true;  
}

bool Login(const char*str)
{
     sformat(strsendbuffer,"%s<clientType>1</clientType>",str);
     if(tcpClient.write(strsendbuffer)==false)
     {
         return false;
     }
     if(tcpClient.read(strrecvbuffer,10)==false)
     {
         return false;
     }
     cout<<strrecvbuffer<<endl;
     logFile.write("login (%s) (%d) 成功\n",ArgInfo.ip,ArgInfo.port);
     return true;

}
bool _tcpputfile(bool & fg)
{

}

bool acttest()
{

}

