#include <iostream>
#include <string>
#include <stdio.h>

using namespace std;

class SingleTon{
    
};


void test()
{

}
int main()
{
    test();
    return 0;
}

