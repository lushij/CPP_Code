#pragma once
inline
int add(int x,int y);
