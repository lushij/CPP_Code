#include <iostream>
#include <string>
#include <stdio.h>
#include "inline.hpp"
using namespace std;

void test()
{
    int ret = add(1,2);
}
int main()
{
    test();
    return 0;
}

