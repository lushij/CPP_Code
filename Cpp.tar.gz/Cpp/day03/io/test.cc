#include <iostream>
#include <string>
#include <stdio.h>

using namespace std;

void test()
{
    string name;
    cin>>name;
    cout<<name;
}
int main()
{
    test();
    return 0;
}

