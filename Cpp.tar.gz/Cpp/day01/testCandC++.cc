#include <iostream>
#include <string>
#include <stdio.h>
/* #include"headCandC++.hpp" */
#include "headp.hpp"
using namespace std;

void test()
{
    int ret = add(1,2);
    cout<<ret<<endl;
}
int main()
{
    test();
    return 0;
}

