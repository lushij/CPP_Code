#pragma once

//大写C
extern "C"
{
    //该区域的按照c编译进行
    int add(int x,int y){
        return x+y;
    }
}//end of extern "C"
